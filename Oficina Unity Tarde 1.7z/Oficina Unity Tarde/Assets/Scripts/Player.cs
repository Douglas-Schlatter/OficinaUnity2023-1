﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player : MonoBehaviour {
    public Rigidbody2D rb;
    public int moveSpeed = 10;
    public int score = 0;
    Vector2 movement;
	
	// Update is called once per frame
	void Update () {
		
	}

    void FixedUpdate()
    {
        movement.x = Input.GetAxis("Horizontal");
        rb.MovePosition(rb.position + moveSpeed * movement * Time.deltaTime);
    }
}
