﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Spawner : MonoBehaviour {
    public GameObject coin;
    public List<GameObject> spawnPos;
    public int target;

    //Timer Related
    public float timer = 0.0f;
    public float lSpawn = 0.0f;
    public float sTime = 1.0f;

    private void FixedUpdate()
    {
        timer += Time.deltaTime;
        if(timer -lSpawn > sTime)
        {
            lSpawn = timer;
            target = Random.Range(0, 4);

            Instantiate(coin, spawnPos[target].transform.position, spawnPos[target].transform.rotation);
        }
        
    }
}
