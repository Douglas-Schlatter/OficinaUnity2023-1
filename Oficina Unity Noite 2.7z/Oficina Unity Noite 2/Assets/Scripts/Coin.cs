﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Coin : MonoBehaviour {

    public bool isCatch = false;

    private void OnTriggerEnter2D(Collider2D col)
    {
        //Debug.Log(col.tag);
        if (col.tag == "Player" && !isCatch)
        {
            isCatch = true;
            col.GetComponent<Player>().score = col.GetComponent<Player>().score + 1;
            Destroy(this.gameObject);
        }
        else if (col.tag == "Ground" && !isCatch)
        {
            isCatch = true;
            Destroy(this.gameObject);
        }
    }
}
