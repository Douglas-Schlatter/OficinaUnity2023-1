﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Player : MonoBehaviour {
    public Rigidbody2D rb;
    public int moveSpeed = 10;
    public int score = 0;
    public Text scoreText;
    Vector2 movement;
	
	// Update is called once per frame
	void Update () {
		
	}
    // Update is called once per frame
    void FixedUpdate()
    {
        movement.x = Input.GetAxis("Horizontal");
        rb.MovePosition(rb.position + moveSpeed * movement * Time.deltaTime);
        scoreText.text = "Score: " + score.ToString();
    }
}
