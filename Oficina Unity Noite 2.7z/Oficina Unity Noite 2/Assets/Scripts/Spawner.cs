﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Spawner : MonoBehaviour {
    public GameObject coin;
    public List<GameObject> spawnPos;
    public int target;
    public float cons = 1.0f;

    //Timer related stuff
    public float timer = 0.0f;
    public float lSpawn = 0.0f;

    private void FixedUpdate()
    {
        timer += Time.deltaTime;
        if (timer - lSpawn > cons)
        {
            target = Random.Range(0, 5);
            lSpawn = timer;
            Instantiate(coin, spawnPos[target].transform.position, spawnPos[target].transform.rotation);
        }
    }
}
