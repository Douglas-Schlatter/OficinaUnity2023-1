﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Coin : MonoBehaviour {

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}

    


    private void OnTriggerEnter2D(Collider2D col)
    {
        Debug.Log(col.tag);
        if (col.tag == "Player")
        {
            col.GetComponent<Player>().score = col.GetComponent<Player>().score + 1;
            Destroy(this.gameObject);
        }
        else if (col.tag == "Ground")
        {
            Destroy(this.gameObject);
        }
    }
}
